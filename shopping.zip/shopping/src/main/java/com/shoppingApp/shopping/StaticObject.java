package com.shoppingApp.shopping;

import com.shoppingApp.shopping.model.Product;


import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StaticObject {

    public static ArrayList<Product> productlist = new ArrayList<Product>();

       static {

           Product product1 = new Product(1,"pencil",2,5.5);
           Product product2 = new Product(2,"stationary pad",5,7.8);
           productlist.add(product1);
           productlist.add(product2);
       }


    }






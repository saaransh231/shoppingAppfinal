package com.shoppingApp.shopping.model;

import jakarta.persistence.Column;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Order {

    List<Product> shoppingCartlist = new ArrayList<Product>();

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double totalAmount;

    private Customer customer;

    @Column(name = "name", nullable = false, unique = true)
    private String orderDescription;

    @Column(name = "OrderDate")
    private Date orderDate;

    public List<Product> getShoppingCartlist() {
        return shoppingCartlist;
    }

    public void setShoppingCartlist(List<Product> shoppingCartlist) {
        this.shoppingCartlist = shoppingCartlist;
    }

    public String getOrderDescription() {
        return orderDescription;
    }

    public void setOrderDescription(String orderDescription) {
        this.orderDescription = orderDescription;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
}

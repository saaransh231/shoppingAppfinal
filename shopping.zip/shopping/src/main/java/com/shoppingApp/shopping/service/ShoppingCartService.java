package com.shoppingApp.shopping.service;

import com.shoppingApp.shopping.StaticObject;
import com.shoppingApp.shopping.model.Order;
import com.shoppingApp.shopping.model.Product;
import com.shoppingApp.shopping.repository.ShoppingCartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShoppingCartService {

    @Autowired
    private ShoppingCartRepository shoppingCartRepository;

    public Double calculate(Order order) {
        Double totalAmount = 0.0;
        List<Product> list1 = order.getShoppingCartlist();

        for(Product sh : list1){
            int id = sh.getId();
            Product product = StaticObject.productlist.get(id);
            totalAmount = product.getPrice() * sh.getQuantity();
            return totalAmount;

        }
        return null;
    }
}
